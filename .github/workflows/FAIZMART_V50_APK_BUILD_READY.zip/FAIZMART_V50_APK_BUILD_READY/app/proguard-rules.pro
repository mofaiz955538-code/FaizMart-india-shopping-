# FAIZMART V50 - no custom ProGuard rules required.
